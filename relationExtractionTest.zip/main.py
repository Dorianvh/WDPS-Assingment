import spacy
import re
import random
from pprint import pprint
import requests
from bs4 import BeautifulSoup
import spacy_component


API_URL = "https://www.wikidata.org/w/api.php"


def getEntityCandidateInfo(entity_id, languages="en") -> dict:
    """collect relevant information on an entity such as sitelinks, statements and description

    Args:
        entity_id (string): id of an entity
        languages (str, optional)

    Returns:
        dict: returns a detailed dictionairy of a given entity
    """

    response = requests.get(API_URL, params={"action": "wbgetentities", "ids": entity_id, "format": "json", "languages": languages})

    if response.status_code == 200:
        data = response.json()

        if "entities" in data and entity_id in data["entities"]:
            entity = data.get("entities").get(entity_id)

            # Get label and description of entity
            label = entity["labels"]["en"]["value"]
            description = entity["descriptions"]["en"]["value"]

            # Get the number of linked sites
            num_sitelinks = len(entity["sitelinks"].keys())

            # Claims
            claims_data = len(entity["claims"].keys())

            # Wikepedia url
            # Get the sites linked to this entity
            wikipedia_url = entity["sitelinks"].get("enwiki")

            if wikipedia_url:
                url = "https://en.wikipedia.org/wiki/" + wikipedia_url["title"].replace(" ", "_")
            else:
                url = ""

            return {"label": label, "description": description, "claims": claims_data, "sitelinks": num_sitelinks, "url": url}

    return {}


def getEntityCandidates(entity, language="en", limit=5) -> list:
    """get a list of candidates for a specific entity

    Args:
        entity (string): name of the entity you want to search
        language (str, optional): Defaults to "en".
        limit (int, optional): Defaults to 5.

    Returns:
        list: list of IDs found for this entity
    """

    response = requests.get(API_URL, params={"action": "wbsearchentities", "search": entity, "language": language, "format": "json", "limit": limit})

    if response.status_code == 200:
        data = response.json()

        candidates = []

        for entity in data.get("search", []):
            candidates.append(entity["id"])

        return candidates

    return {}


def getEntityInfo(entity_id):

    # Fetch the HTML content
    response = requests.get(f"https://www.wikidata.org/wiki/{entity_id}")

    # Parse the HTML content with BeautifulSoup
    soup = BeautifulSoup(response.text, "html.parser")

    # Locate the main section containing properties and values
    statments_table = soup.select_one(".wikibase-statementgrouplistview")
    properties_table = statments_table.select(".wikibase-statementgroupview")

    # Store properties in statements dict
    statements = {}

    # Loop through properties
    for prop in properties_table:

        label = prop.select(".wikibase-statementgroupview-property-label > a")[0].get_text()

        values = []
        for value in prop.select(".wikibase-statementview"):
            v = value.select_one(".wikibase-snakview-value.wikibase-snakview-variation-valuesnak")
            if v:
                values.append(v.get_text())

        statements[label] = values

    return statements


def getTypeOfQuestion(question):
    boolean_patterns = [
        r"^(is|are|was|were|do|does|did|can|could|will|would|shall|should|have|has|had|may|might|must|won’t|don’t|doesn’t|didn’t|can’t|shouldn’t|isn’t|aren’t)\b.*",
        r"\b(True or False|Yes or No|Correct or Incorrect|Confirm or Deny|Verify)\b",
    ]

    for pattern in boolean_patterns:
        if re.search(pattern, question.strip(), re.IGNORECASE):
            return "Yes/No"

    return "Entity"


def getRelations(question):
    return [(rel_dict["head_span"], rel_dict["relation"], rel_dict["tail_span"]) for _, rel_dict in nlp(question)._.rel.items()]


def getEntities(question):

    doc = nlp(question)

    with doc.retokenize() as retokenizer:
        for ent in doc.ents:
            retokenizer.merge(ent)

    dont_include_labels = ["DATE", "TIME", "PERCENT", "MONEY", "QUANTITY", "ORDINAL", "CARDINAL"]

    seen = set()

    return [(entity.text, entity.label_) for entity in doc.ents if (entity.label_ not in dont_include_labels) and not (entity.label_ in seen or seen.add(entity.label_))]


def disambiguateEntities(entities):

    resolved_entities = []

    for entity in entities:

        # Get top-k search results for given entity
        candidates_ids = getEntityCandidates(entity[0], limit=5)
        candidates_info = []

        # loop through the entities and obtain simple information + metrics for popularity
        for id in candidates_ids:
            candidate = getEntityCandidateInfo(id)
            candidate.update({"id": id})
            candidates_info.append(candidate)

        # Pick the most popular, and populate with all available information on this specific entity
        resolved_entity = sorted(candidates_info, key=lambda x: x["sitelinks"], reverse=True)[0]

        properties = getEntityInfo(resolved_entity["id"])

        resolved_entity.update({"properties": properties})

        resolved_entities.append(resolved_entity)

    return resolved_entities


def preprocess(question, answer):

    return {
        "question": {
            "text": question,
            # "entities": disambiguateEntities(getEntities(question)),
            "entities": getEntities(question),
            "relations": getRelations(question),
            "type": getTypeOfQuestion(question),
        },
        "answer": {
            "text": answer,
            "entities": getEntities(answer),
            "relations": getRelations(answer),
        },
    }


if __name__ == "__main__":

    nlp = spacy.load("en_core_web_lg")

    nlp.add_pipe(
        "rebel",
        after="senter",
        config={"device": 0, "model_name": "Babelscape/rebel-large"},  # Number of the GPU, -1 if want to use CPU  # Model used, will default to 'Babelscape/rebel-large' if not given
    )

    def load_QA():

        data = []

        with open("QA.txt", "r") as file:
            for line in file:
                q, a = line.replace("\n", "").split(" || ")
                data.append((q, a))

        return data

    data = load_QA()

    for q, a in data[0:20]:

        processed_item = preprocess(q, a)
        pprint(processed_item)
        print()

        # getAnswerToQuestion(processed_item["question"])
        # print("")
